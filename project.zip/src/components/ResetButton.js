const ResetButton = ({ onReset }) => {
  return (
    <button
      onClick={onReset}
      className="mt-6 px-6 py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg transition-all transform hover:scale-105"
    >
      Reiniciar Votación
    </button>
  );
};

export default ResetButton;