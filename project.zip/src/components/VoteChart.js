const VoteChart = ({ votes }) => {
  const totalVotes = votes.yes + votes.no;
  const yesPercentage = totalVotes > 0 ? (votes.yes / totalVotes) * 100 : 0;
  const noPercentage = totalVotes > 0 ? (votes.no / totalVotes) * 100 : 0;

  return (
    <div className="w-full max-w-2xl mx-auto mb-8">
      <div className="flex justify-between mb-2">
        <span className="text-green-400 font-medium">Sí: {votes.yes} ({Math.round(yesPercentage)}%)</span>
        <span className="text-red-400 font-medium">No: {votes.no} ({Math.round(noPercentage)}%)</span>
      </div>
      <div className="flex h-12 bg-gray-800 rounded-lg overflow-hidden">
        <div 
          className="bg-green-600 transition-all duration-500 flex items-center justify-end pr-2"
          style={{ width: `${yesPercentage}%` }}
        >
          {yesPercentage > 10 && <span className="text-white font-bold">{Math.round(yesPercentage)}%</span>}
        </div>
        <div 
          className="bg-red-600 transition-all duration-500 flex items-center pl-2"
          style={{ width: `${noPercentage}%` }}
        >
          {noPercentage > 10 && <span className="text-white font-bold">{Math.round(noPercentage)}%</span>}
        </div>
      </div>
    </div>
  );
};

export default VoteChart;