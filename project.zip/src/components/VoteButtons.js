const VoteButtons = ({ onVote, voterName, setVoterName }) => {
  return (
    <div className="flex flex-col items-center space-y-4 mb-8">
      <input
        type="text"
        value={voterName}
        onChange={(e) => setVoterName(e.target.value)}
        placeholder="Tu nombre o seudónimo"
        className="w-64 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
        required
      />
      <div className="flex space-x-8">
        <button
          onClick={() => onVote('yes')}
          disabled={!voterName}
          className={`px-12 py-6 text-2xl font-bold rounded-xl transition-all ${!voterName ? 'bg-gray-700 cursor-not-allowed' : 'bg-green-600 hover:bg-green-500 transform hover:scale-105'} shadow-lg`}
        >
          SÍ
        </button>
        <button
          onClick={() => onVote('no')}
          disabled={!voterName}
          className={`px-12 py-6 text-2xl font-bold rounded-xl transition-all ${!voterName ? 'bg-gray-700 cursor-not-allowed' : 'bg-red-600 hover:bg-red-500 transform hover:scale-105'} shadow-lg`}
        >
          NO
        </button>
      </div>
    </div>
  );
};

export default VoteButtons;