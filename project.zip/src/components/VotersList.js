const VotersList = ({ voters }) => {
  return (
    <div className="w-full max-w-md mx-auto bg-gray-900 bg-opacity-70 rounded-xl p-4">
      <h3 className="text-xl font-bold text-purple-400 mb-4">Últimos votantes</h3>
      <ul className="space-y-2">
        {voters.slice().reverse().map((voter, index) => (
          <li key={index} className="flex justify-between items-center py-2 px-3 bg-gray-800 rounded-lg">
            <span className="text-gray-300">{voter.name}</span>
            <span className={`px-2 py-1 rounded text-xs font-bold ${voter.vote === 'yes' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300'}`}>
              {voter.vote === 'yes' ? 'SÍ' : 'NO'}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default VotersList;