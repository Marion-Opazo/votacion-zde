import React, { useState, useEffect } from 'react';
import VoteButtons from './components/VoteButtons';
import VoteChart from './components/VoteChart';
import VotersList from './components/VotersList';
import ResetButton from './components/ResetButton';

const App = () => {
  const [votes, setVotes] = useState(() => {
    const savedVotes = JSON.parse(localStorage.getItem('votes'));
    return savedVotes || { yes: 0, no: 0 };
  });

  const [voters, setVoters] = useState(() => {
    const savedVoters = JSON.parse(localStorage.getItem('voters'));
    return savedVoters || [];
  });

  const [voterName, setVoterName] = useState('');

  useEffect(() => {
    localStorage.setItem('votes', JSON.stringify(votes));
    localStorage.setItem('voters', JSON.stringify(voters));
  }, [votes, voters]);

  const handleVote = (voteType) => {
    setVotes(prev => ({ ...prev, [voteType]: prev[voteType] + 1 }));
    setVoters(prev => [...prev, { name: voterName, vote: voteType, timestamp: new Date().toISOString() }]);
    setVoterName('');
  };

  const handleReset = () => {
    setVotes({ yes: 0, no: 0 });
    setVoters([]);
  };

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-4 text-white"
      style={{ 
        backgroundImage: `url('https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc03ygSC4ku0HlIPwSxAEOXk6nTjd9beaNftrh5')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="absolute inset-0 bg-black bg-opacity-70"></div>
      
      <div className="relative z-10 w-full max-w-4xl text-center">
        <img 
          src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc0lYSuPsXbcAaSYNqKr0LMw3z9nWTuy4eIjixU" 
          alt="Logo" 
          className="mx-auto mb-8 h-40" /* Cambiado de h-24 a h-40 */
        />
        
        <div className="bg-gray-900 bg-opacity-80 backdrop-blur-sm rounded-2xl p-8 shadow-2xl border border-gray-800">
          <VoteButtons onVote={handleVote} voterName={voterName} setVoterName={setVoterName} />
          <VoteChart votes={votes} />
          <VotersList voters={voters} />
          <ResetButton onReset={handleReset} />
        </div>
        
        <div className="mt-8 text-gray-400">
          <p>Total de votos: {votes.yes + votes.no}</p>
        </div>
      </div>
    </div>
  );
};

export default App;

// DONE